<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use Illuminate\Http\Request;

class BarangConttroler extends Controller
{
    public function index()
    {
        return Barang::all();
    }
    public function store(Request $request)
    {
        return Barang::create($request->all());
    }
    public function show($id){
        return Barang::findOrFail($id);   
    }
    public function update(Request $request, $id)
    {
        $update = Barang::findOrFail($id);
        $update->update($request->all());
        return $update;    
    }
    public function destroy($id)
    {
        return Barang::destroy($id);
    }
}